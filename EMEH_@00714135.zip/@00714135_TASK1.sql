-----Create Database for Hospital Management
CREATE database HospitalManagementSytem;
USE HospitalManagementSystem;


--------CREATION OF TABLES

CREATE TABLE Departments (
    DepartmentID VARCHAR(50) PRIMARY KEY,
    DepartmentName VARCHAR(50) NOT NULL,
);


CREATE TABLE Doctors (
    DoctorID VARCHAR(50) PRIMARY KEY,
    FirstName NVARCHAR(100) NOT NULL,
	MiddleName NVARCHAR(100),
	LastName NVARCHAR(100) NOT NULL,
	Specialty VARCHAR(50) NOT NULL,
    Email VARCHAR(100) DEFAULT NULL,
	PhoneNumber  VARCHAR(50) NOT NULL,
    DepartmentID VARCHAR(50) NOT NULL,
    FOREIGN KEY (DepartmentID) REFERENCES Departments (DepartmentID)
);

CREATE TABLE DoctorsAvailability (
ScheduleID VARCHAR(50) PRIMARY KEY,
DoctorID VARCHAR(50) NOT NULL,
ScheduleDate DATE NOT NULL,
StartTime TIME NOT NULL, 
EndTime TIME NOT NULL,
FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID)
);



CREATE TABLE Patients (
    PatientID INT IDENTITY (1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
	MiddleName NVARCHAR(50),
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE NOT NULL,
	Address NVARCHAR(200) NOT NULL,
	PhoneNumber VARCHAR(15) NOT NULL,
	EmailAddress NVARCHAR(100) NOT NULL,
	InsuranceNumber VARCHAR(50) NOT NULL,
	Username VARCHAR(50) NOT NULL,
	Password VARCHAR(50) NOT NULL,
    RegistrationDate DATE NOT NULL, 
    LeaveDate DATE NULL 
);

CREATE TABLE Appointments (
    AppointmentID VARCHAR(50) PRIMARY KEY,
    PatientID INT,
    DoctorID VARCHAR(50),
	DepartmentID VARCHAR(50),
    AppointmentDate DATE NOT NULL,
    AppointmentTime TIME NOT NULL,
	Review NVARCHAR(MAX) NOT NULL,
    Status VARCHAR(20) CHECK (Status IN ('Pending', 'Cancelled', 'Completed')),
	FOREIGN KEY (PatientID) REFERENCES Patients(PatientID), 
	FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID), 
	FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID) 
);


CREATE TABLE MedicalRecords (
    MedicalRecordID  varchar(50) PRIMARY KEY,  
    PatientID INT,
    DoctorID  varchar(50),
    AppointmentDate DATE  NOT NULL,
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID)
);

CREATE TABLE Prescription (    
    PrescriptionID VARCHAR(50) PRIMARY KEY,
	MedicalRecordID VARCHAR(50),
    MedicineName VARCHAR(100) NOT NULL,
    MedicinePrescribedDate DATE NOT NULL,
    Dosage VARCHAR(50) NOT NULL,
    Frequency VARCHAR(50) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
	FOREIGN KEY (MedicalRecordID) REFERENCES MedicalRecords(MedicalRecordID)   
);

CREATE TABLE MedicalRecords_Diagnosis (
    MRD_ID VARCHAR(50) ,  
    Diagnosis varchar(50) NOT NULL,
    FOREIGN KEY (MRD_ID) REFERENCES MedicalRecords(MedicalRecordID),
    PRIMARY KEY (MRD_ID, Diagnosis)
);


CREATE TABLE MedicalRecords_Allergy (
    MRA_ID  varchar(50) NOT NULL, 
    Allergy varchar(100) NOT NULL,
    FOREIGN KEY (MRA_ID) REFERENCES MedicalRecords (MedicalRecordID),
    PRIMARY KEY (MRA_ID, Allergy)
)


--------POPULATING TABLES
-- Insert statements for Departments table
INSERT INTO Departments (DepartmentID, DepartmentName) VALUES
('DR1', 'Cardiology'),
('DR2', 'Neurology'),
('DR3', 'Orthopedics'),
('DR4', 'Pediatrics'),
('DR5', 'Oncology'),
('DR6', 'Gynecology'),
('DR7', 'Gastroenterology');



-- Insert statements for Doctors table
INSERT INTO Doctors (DoctorID, FirstName, MiddleName, LastName, Specialty, Email, PhoneNumber, DepartmentID) VALUES
('D10','Adim','James','Johnson','Orthopedic Surgeon','adimjohnson@yahoo.com','345-678-9045','DR3'),
('D11','Emily','NULL','Okem','Pediatrician','emilyoke@yandex.com','456-789-0176','DR4'),
('D12','David','Charles','Wilson',	'Oncologist',	'davidwilson@ru.com','567-890-1234','DR5'),
('D13','Oge','Maria',	'Martinez','Gynecologist','ogemartinez@gmail.com','678-901-2354','DR6'),
('D14','Martha','NULL','Taylor','Gastroenterologist','mmataylor@outlook.com','789-012-3478','DR7'),
('D8','Nkechi','Edaward','Kalu','Cardiologist','nkelu@gmail.com	','123-456-7999','DR1'),
('D9','Alice','NULL','Mba','Neurologist',	'alicemba@gmail.com','234-567-8934','DR2');

-- Insert statements for DoctorsAvailability table
INSERT INTO DoctorsAvailability (ScheduleID, DoctorID, ScheduleDate, StartTime, EndTime) VALUES
('S8', 'D8', '2024-04-21', '08:00:00', '20:00:00'),
('S9', 'D9', '2024-04-22', '08:00:00', '20:00:00'),
('S10', 'D10', '2024-04-23', '08:00:00', '20:00:00'),
('S11', 'D11', '2024-04-24', '08:00:00', '20:00:00'),
('S12', 'D12', '2024-04-25', '08:00:00', '20:00:00'),
('S13', 'D13', '2024-04-26', '08:00:00', '20:00:00'),
('S14', 'D14', '2024-04-27', '08:00:00', '20:00:00');


-- Insert statements for Patients table
INSERT INTO Patients (FirstName, MiddleName, LastName, DateOfBirth, Address, PhoneNumber, EmailAddress, InsuranceNumber, Username, Password, RegistrationDate, LeaveDate) VALUES
('Ifeanyi', 'Ben', 'Clark', '1975-01-01', '123 Main St', '123-456-7890', 'ifyclark@gmail.com', '123456789', 'ify123', 'password', '2022-01-01', NULL),
('Onyi', NULL, 'Ore', '1970-05-05', '764 Oak St', '234-567-8901', 'onyimoore@yaoo.com', '234567890', 'ony456', 'password123', '2022-02-01', NULL),
('Sophia', 'Rosa', 'Nkem', '1971-10-10', '876 Elm St', '345-678-9012', 'sophiankem@hotmail.com', '345678901', 'sia789', 'password456', '2022-03-01', NULL),
('Ethan', NULL, 'Emeh', '1965-03-15', '202 Pine St', '456-789-0123', 'ethanemeh@yandex.com', '456789012', 'etha01', 'password789', '2022-04-01', NULL),
('Helen', 'Grace', 'Chidi', '1978-06-20', '203 Cedar St', '567-890-1234', 'helen@gmail.com', '567890123', 'helbella202', 'passwordabc', '2022-05-01', NULL),
('Andrew', NULL, 'Ope', '1976-09-25', '303 Maple St', '678-901-2345', 'andrew@outlook.com', '678901234', 'andy303', 'passworddef', '2022-06-01', NULL),
('Benjamin', 'Nnamdi', 'Okoye', '1970-12-30', '404 Walnut St', '789-012-3456', 'aben@korumail.com', '789012345', 'okoye404', 'passwordegf', '2022-07-01', NULL),
('Ada','Gregg','Lark','1970-01-01','13 Min St','123-446-7690','adalark@gmail.com','123t54789','ada123','passweed','2021-01-01',NULL),
('Oni','NULL',	'Ere',	'1965-05-05','74 Tak St','224-547-8901','onimre@yahoo.com',	'234563850','on1436',	'paword123','2012-02-01',NULL),
('Sapia	','Osa','Ikem','1973-10-10','76 Elem St','345-648-9032','saphiaikem@hotmail.com','345279901','sai789','passord426','2019-03-01',NULL),
('Ehian','NULL',	'Umeh','1968-03-15','02 Pinet St','456-729-1123','ehianumeh@yandex.com','457u89212','ethi01','password229','2018-04-01',NULL),
('Heen	','Gace','Chida','1972-06-20','20 Cesri St','567-290-1134',	'heen@gmail.com','5672rr113','heballa202','passwordbc','2016-01-01',NULL),
('Andy','NULL','Wope','1977-09-25','33 Male St','678-901-2345','andy@outlook.com','6749ed234','andy303','passworddef','2021-06-01',NULL),
('Bemin',	'Nadi','Ukoye','1972-12-30','40 Ulnut St','789-012-3456','ben@korumail.com','789kk2345','ukoye404','pas33ordegf','2004-07-01',NULL);


INSERT INTO Appointments (AppointmentID, PatientID, DoctorID, DepartmentID, AppointmentDate, AppointmentTime, Review, Status) VALUES
('AP1', 12, 'D8', 'DR1', '2024-04-27', '08:00:00.0000000', 'Good service', 'Completed'),
('AP2', 13, 'D10', 'DR3', '2024-04-24', '19:00:00.0000000', 'Excellent', 'Completed'),
('AP3', 14, 'D14', 'DR7', '2024-04-25', '18:00:00.0000000', 'Satisfied', 'Completed'),
('AP4', 15, 'D9', 'DR2', '2024-05-25', '16:00:00.0000000', 'Very good', 'Pending'),
('AP5', 16, 'D12', 'DR5', '2024-04-23', '12:00:00.0000000', 'Excellent', 'Pending'),
('AP6', 17, 'D14', 'DR7', '2024-04-23', '13:00:00.0000000', 'Satisfied', 'Completed'),
('AP7', 18, 'D9', 'DR2', '2024-05-01', '09:00:00.0000000', 'Satisfied', 'Cancelled'),
('AP8', 19, 'D10', 'DR3', '2024-05-16', '10:00:00.0000000', 'Very good', 'Cancelled'),
('AP9', 20, 'D11', 'DR4', '2024-04-23', '11:00:00.0000000', 'Not good', 'Completed'),
('AP10', 21, 'D12', 'DR5', '2024-04-22', '12:00:00.0000000', 'Excellent', 'Completed'),
('AP11', 22, 'D13', 'DR6', '2024-04-22', '13:00:00.0000000', 'Very good', 'Cancelled'),
('AP12', 23, 'D14', 'DR7', '2024-04-22', '14:00:00.0000000', 'Satisfied', 'Completed'),
('AP13', 24, 'D8', 'DR1', '2024-04-22', '16:00:00.0000000', 'Very good', 'Completed'),
('AP14', 25, 'D12', 'DR5', '2024-04-22', '20:00:00.0000000', 'Very good', 'Completed');




INSERT INTO MedicalRecords (MedicalRecordID, PatientID, DoctorID, AppointmentDate) VALUES
('MR1', 12, 'D8', '2024-04-27'),
('MR2', 13, 'D10', '2024-04-24'),
('MR3', 14, 'D14', '2024-04-25'),
('MR4', 15, 'D9', '2024-05-25'),
('MR5', 16, 'D12', '2024-04-23'),
('MR6', 17, 'D14', '2024-04-23'),
('MR7', 18, 'D9', '2024-05-01'),
('MR8', 19, 'D10', '2024-05-16'),
('MR9', 20, 'D11', '2024-04-23'),
('MR10', 21, 'D12', '2024-04-22'),
('MR11', 22, 'D13', '2024-04-22'),
('MR12', 23, 'D14', '2024-04-22'),
('MR13', 24, 'D8', '2024-04-22'),
('MR14', 25, 'D12', '2024-04-22');




-- Insert statements for Prescription table
INSERT INTO Prescription (PrescriptionID, MedicalRecordID, MedicineName, MedicinePrescribedDate, Dosage, Frequency, StartDate, EndDate) 
VALUES
('PRA', 'MR1', 'Statins', '2024-04-14', '10mg', 'Once daily', '2024-05-14', '2024-05-31'),
('PRB', 'MR2', 'Antidepressants', '2024-05-15', '20mg', 'Twice daily', '2024-05-15', '2024-05-28'),
('PRC', 'MR3', 'Corticosteroids', '2024-05-16', '15mg', 'Three times daily', '2024-05-16', '2024-05-30'),
('PRD', 'MR4', 'Vaccines', '2024-04-20', '30mg', 'Once daily', '2024-05-17', '2024-06-30'),
('PRE', 'MR5', 'Chemotherapy agents', '2024-06-18', '25mg', 'Twice daily', '2024-06-18', '2024-08-31'),
('PRF', 'MR6', 'Antifungals', '2024-03-21', '40mg', 'Once daily', '2024-07-19', '2024-07-30'),
('PRG', 'MR7', 'Laxatives', '2024-03-22', '35mg', 'Twice daily', '2024-05-07', '2024-08-31'),
('PRH', 'MR8', 'Statins', '2024-04-20', '10mg', 'Once daily', '2024-04-18', '2024-04-30'),
('PRI', 'MR9', 'Antidepressants', '2024-04-20', '20mg', 'Twice daily', '2024-04-18', '2024-05-28'),
('PRJ', 'MR10', 'Corticosteroids', '2024-04-20', '15mg', 'Three times daily', '2024-05-18', '2024-05-30'),
('PRK', 'MR11', 'Vaccines', '2024-04-20', '30mg', 'Once daily', '2024-04-18', '2024-06-30'),
('PRL', 'MR12', 'Antidepressants', '2024-05-25', '20mg', 'Twice daily', '2024-05-25', '2024-05-28'),
('PRM', 'MR13', 'Chemotherapy agents', '2024-03-13', '25mg', 'Twice daily', '2024-07-13', '2024-08-31'),
('PRN', 'MR14', 'Antifungals', '2024-03-29', '40mg', 'Once daily', '2024-07-29', '2024-08-30');



-- Insert statements for MedicalRecords_Diagnosis table
INSERT INTO MedicalRecords_Diagnosis (MRD_ID, Diagnosis) VALUES
('MR1', 'Hypertension'),
('MR10', 'Tendinitis'),
('MR11', 'Endometriosis'),
('MR12', 'Neuropathy'),
('MR13', 'Cancer'),
('MR14', 'Endometriosis'),
('MR2', 'Neuropathy'),
('MR3', 'Tendinitis'),
('MR4', 'Asthma'),
('MR5', 'Cancer'),
('MR6', 'Endometriosis'),
('MR7', 'Pancreatitis'),
('MR8', 'Cancer'),
('MR9', 'Neuropathy');


-- Insert statements for MedicalRecords_Allergy table
INSERT INTO MedicalRecords_Allergy (MRA_ID, Allergy) VALUES
('MR1', 'yes'),
('MR10', 'no'),
('MR11', 'yes'),
('MR12', 'yes'),
('MR13', 'no'),
('MR14', 'yes'),
('MR2', 'yes'),
('MR3', 'yes'),
('MR4', 'no'),
('MR5', 'no'),
('MR6', 'yes'),
('MR7', 'no'),
('MR8', 'yes'),
('MR9', 'no');



--Question 2
--To add a constrain to check that the appoinment date is not in the past
ALTER TABLE dbo.Appointments
ADD CONSTRAINT Check_AppointmentDateNotInPast
CHECK (AppointmentDate >= CAST(GETDATE() AS DATE));


SELECT* from Doctors
SELECT* from Appointments
SELECT* from Departments
SELECT* from DoctorsAvailability
SELECT* from MedicalRecords
SELECT* from MedicalRecords_Diagnosis
SELECT* from MedicalRecords_Allergy
SELECT* from Patients
SELECT* from Prescription

--Question 3
--List all the patients with older than 40 and have Cancer in diagnosis
SELECT DISTINCT
    p.PatientID,
    p.FirstName,
    p.LastName,
    p.DateOfBirth,
    m.Diagnosis
FROM 
    Patients p
JOIN 
    MedicalRecords mr ON p.PatientID = mr.PatientID
JOIN 
    MedicalRecords_Diagnosis m ON mr.MedicalRecordID = m.MRD_ID
WHERE 
    p.DateOfBirth < DATEADD(YEAR, -40, GETDATE()) 
    AND UPPER(m.Diagnosis) LIKE '%CANCER%';  



--Question 4A Search Procedure to check a particular medicine Name
CREATE PROCEDURE SearchMedicineByName
    @MedicineName VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        p.FirstName,
        p.LastName,
        pmd.MedicineName,
        pmd.MedicinePrescribedDate
    FROM 
        Patients p
    JOIN 
        MedicalRecords mr ON p.PatientID = mr.PatientID
    JOIN 
        Prescription pmd ON mr.MedicalRecordID = pmd.MedicalRecordID
    WHERE 
        UPPER(pmd.MedicineName) LIKE '%' + UPPER(@MedicineName) + '%'
    ORDER BY 
        pmd.MedicinePrescribedDate DESC;

END;

EXEC SearchMedicineByName @MedicineName = 'Statins';


------4B Return a full list of diagnosis and allergies or a specific patient who has an appointmnet today(i.e , the system date when the query is run) with User Define Function
----since i have more than one patient for the date
CREATE FUNCTION GetPatientsDiagnosisAndAllergiesToday()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        p.PatientID,
        p.FirstName,
        p.LastName,
        md.Diagnosis,
        ma.Allergy
    FROM 
        Patients p
    LEFT JOIN 
        MedicalRecords mr ON p.PatientID = mr.PatientID
    LEFT JOIN 
        MedicalRecords_Diagnosis md ON mr.MedicalRecordID = md.MRD_ID
    LEFT JOIN 
        MedicalRecords_Allergy ma ON mr.MedicalRecordID = ma.MRA_ID
    WHERE 
        mr.AppointmentDate = CAST(GETDATE() AS DATE)
);
SELECT * FROM dbo.GetPatientsDiagnosisAndAllergiesToday();-------since i have more than one patient for same day 


------4C Stored Procedure to Update an existing Doctors details
CREATE PROCEDURE UpdateDoctorDetails
    @DoctorID VARCHAR(50), @FirstName NVARCHAR(50), @MiddleName NVARCHAR(50) = NULL, @LastName NVARCHAR(50),
    @Specialty NVARCHAR(50), @Email NVARCHAR(100), @PhoneNumber NVARCHAR(15), @DepartmentID VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Doctors
    SET 
        FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, Specialty = @Specialty, Email = @Email,
        PhoneNumber = @PhoneNumber, DepartmentID = @DepartmentID
    WHERE
        DoctorID = @DoctorID;
    IF @@ROWCOUNT = 0
    BEGIN
        RAISERROR('Doctor with ID %s not found.', 16, 1, @DoctorID);
        RETURN;
    END
    SELECT 'Doctor details updated successfully.' AS Message;
END;


EXEC UpdateDoctorDetails 
    @DoctorID = 'D8', @FirstName = 'Nkechimma', @MiddleName = 'Edaward', @LastName = 'Kalum',
    @Specialty = 'Cardiologist', @Email = 'nkelu_updated@gmail.com', @PhoneNumber = '123-456-7999',
    @DepartmentID = 'DR1';

SELECT*FROM Doctors



--4D Stored Procedure to Delete the appointment who status is already completed.
-- To create a clone Appointment Table in order to retian my data in the Appoinment Table
SELECT *
INTO Clone_Appointment_tb
FROM Appointments;
Select * from Clone_Appointment_tb

--Creating the procedure
CREATE PROCEDURE DeleteCompletedAppointments
AS
BEGIN
    DELETE FROM Clone_Appointment_tb
    WHERE Status = 'Completed';
END;



--The execute query to run the below code
EXEC DeleteCompletedAppointments;
--To crosscheck the clone table to confirm the completed Appoinment has been deleted
select * from Clone_Appointment_tb;


--Question 5 Create a View the appointment date and time, 
---showing all previous and current appointments for all doctors, 
---and including details of the department (the doctor is associated with), 
---doctor�s specialty and any associate review/feedback given for a doctor
CREATE VIEW AllAppointmentsDetails AS
SELECT 
    A.AppointmentID,
    A.AppointmentDate,
    A.AppointmentTime,
    A.Review,
    A.Status,
    D.DoctorID,
    D.FirstName AS DoctorFirstName,
    D.LastName AS DoctorLastName,
    D.Specialty,
    Dep.DepartmentName
FROM 
    Appointments A
JOIN 
    Doctors D ON A.DoctorID = D.DoctorID
JOIN 
    Departments Dep ON D.DepartmentID = Dep.DepartmentID;

	SELECT * FROM AllAppointmentsDetails;





--Question 6 A trigger to Change the Cancelled Appointment To Available
	CREATE TRIGGER UpdateAppointmentStatus
ON Appointments
AFTER UPDATE
AS
BEGIN
    -- Check if the Status column has been updated to 'Cancelled'
    IF UPDATE(Status)
    BEGIN
        UPDATE Appointments
        SET Status = 'Available'
        FROM inserted i
        WHERE Appointments.AppointmentID = i.AppointmentID
        AND i.Status = 'Cancelled';
    END
END;




--7  A select query which allows the hospital to identify the number of completed appointments with the specialty of doctors as �Gastroenterologists�.
SELECT A.AppointmentID, A.AppointmentDate, A.AppointmentTime, A.Status,
       D.DoctorID, D.FirstName AS DoctorFirstName, D.LastName AS DoctorLastName,
       D.Specialty, D.DepartmentID,
       (SELECT COUNT(*)
        FROM Appointments A
        JOIN Doctors D ON A.DoctorID = D.DoctorID
        WHERE A.Status = 'Completed' AND D.Specialty = 'Gastroenterologist') AS NumberOfCompletedGastroenterologistAppointments
FROM Appointments A
JOIN Doctors D ON A.DoctorID = D.DoctorID
WHERE A.Status = 'Completed' AND D.Specialty = 'Gastroenterologist';





-------DATABASE SECURITY AND LOCK FOR ONLY AUTHORIZED USERS


--Database Security
--To create a database Login Users name Database_Admin,Doctors_Mgt,AppointmentMgt_Officer
Create Login Database_Admin with Password = 'EMEH8604$';
Create Login Doctors_Mgt with Password = 'STAN1992$';
Create Login AppointmentMgt_Officer with password ='SELECTION1998$';


-- Create users in the database
Create User Database_Admin for Login Database_Admin;
Create User Doctors_Mgt for Login Doctors_Mgt;
Create User AppointmentMgt_Officer for Login AppointmentMgt_Officer;

--Grant All privileges to Database_Admin
GRANT CONTROL ON SCHEMA::dbo TO Database_Admin;

--Grant privileges to AppointmentMgt_Officer
GRANT SELECT,  INSERT,  UPDATE,  DELETE, ALTER ON dbo.Appointments TO AppointmentMgt_Officer ;
GRANT SELECT,  INSERT,  UPDATE,  DELETE, ALTER ON dbo.Clone_Appointment_tb TO AppointmentMgt_Officer;
GRANT SELECT,  INSERT,  UPDATE,  DELETE, ALTER ON dbo.Patients TO AppointmentMgt_Officer;

--Grant Privileges to Doctors_Mgt
GRANT SELECT,  INSERT,  UPDATE,  DELETE, ALTER ON dbo.Medicalrecords TO Doctors_Mgt;
GRANT SELECT,  INSERT,  UPDATE,  DELETE, ALTER ON dbo.Doctors TO Doctors_Mgt;
GRANT SELECT,  INSERT,  UPDATE,  DELETE, ALTER ON dbo.Departments TO Doctors_Mgt;



-- Grant Stored Procedure Permissions using no Schema access
GRANT EXECUTE ON  DeleteCompletedAppointments TO Database_Admin;
GRANT EXECUTE ON  GetPatientDiagnosisAndAllergies TO Doctors_Mgt;
GRANT EXECUTE ON  UpdateDoctorDetails TO Doctors_Mgt;
GRANT EXECUTE ON  SearchMedicineByName TO AppointmentMgt_Officer;


