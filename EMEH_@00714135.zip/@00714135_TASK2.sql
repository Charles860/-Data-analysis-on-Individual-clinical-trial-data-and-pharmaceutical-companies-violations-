---------         Trimster 1 -ADB Module MARCH 2024        --------------------
---------         Task2--------------------
------PART 1
CREATE DATABASE FoodserviceDB;
USE FoodserviceDB;


select * from consumers

select * from restaurants

select * from ratings

select * from restaurant_cuisines


ALTER TABLE consumers
ADD CONSTRAINT PK_consumers PRIMARY KEY (Consumer_ID);


ALTER TABLE restaurants
ADD CONSTRAINT PK_restaurants PRIMARY KEY (Restaurant_ID);

ALTER TABLE ratings
ADD CONSTRAINT Fk_Consumer
FOREIGN KEY (Consumer_ID) REFERENCES Consumers(Consumer_ID);


ALTER TABLE ratings
ADD CONSTRAINT Fk_Restaurant
FOREIGN KEY (Restaurant_ID) REFERENCES restaurants(Restaurant_ID);

ALTER TABLE restaurant_cuisines
ADD CONSTRAINT Fk_restaurant_cuisines
FOREIGN KEY (Restaurant_ID) REFERENCES restaurants(Restaurant_ID);


----PART 2
----QUESTION 1
SELECT * 
FROM restaurants
WHERE Price = 'Medium' 
AND Area = 'Open' 
AND Restaurant_ID IN (SELECT Restaurant_ID FROM restaurant_cuisines WHERE cuisine = 'Mexican');



------QUESTION 2.
SELECT cuisine, COUNT(*) as Total_restaurants
FROM restaurant_cuisines rc
JOIN ratings r 
ON rc.Restaurant_ID = r.Restaurant_ID
WHERE Overall_Rating = 1
AND (cuisine = 'Mexican' OR cuisine = 'Italian')
GROUP BY cuisine;

------- QUESTION 3.
SELECT ROUND(AVG(c.Age),0) AS Average_Age
FROM consumers c
JOIN ratings r 
ON c.Consumer_ID = r.Consumer_ID
WHERE Service_Rating = 0;


------QUESTION 4.
SELECT r.Restaurant_ID, rest.Name AS Restaurant_Name, MIN(c.Age) AS Youngest_Age, ra.Food_Rating
FROM ratings r
JOIN ratings ra ON r.Restaurant_ID = ra.Restaurant_ID
JOIN consumers c ON ra.Consumer_ID = c.Consumer_ID
JOIN Restaurants rest ON r.Restaurant_ID = rest.Restaurant_ID
GROUP BY r.Restaurant_ID, rest.Name, ra.Food_Rating
ORDER BY Youngest_Age ASC, ra.Food_Rating DESC;


--5. STORED PROCEDURE
CREATE PROCEDURE UpdateServiceRatingWithParking
AS
BEGIN
    UPDATE ratings
    SET Service_Rating = 2
    WHERE Restaurant_ID IN (
        SELECT Restaurant_ID
        FROM restaurants
        WHERE Parking IN ('yes', 'public')
    );
END 

--Execution Procedure
EXEC UpdateServiceRatingWithParking 
SELECT *
FROM ratings


--6.1 EXISTS
SELECT Name, City
FROM restaurants r
WHERE EXISTS (SELECT 1 FROM ratings WHERE r.Restaurant_ID = ratings.Restaurant_ID);


--6.2 IN
SELECT *
FROM Consumers
WHERE City IN (SELECT DISTINCT City FROM restaurants);

--6.3 SYSTEM FUNCTION GROUP BY,HAVING
SELECT Restaurant_ID, COUNT(*) AS Total_Ratings
FROM ratings
GROUP BY Restaurant_ID
HAVING COUNT(*) > 10;

--6.4 SYSTEM FUNCTION GROUP BY,HAVING, ORDER BY
SELECT Country, COUNT(*) AS Total_Restaurants
FROM restaurants
GROUP BY Country
HAVING COUNT(*) > 5
ORDER BY Total_Restaurants DESC;





